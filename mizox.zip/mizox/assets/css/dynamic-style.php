<?php

// Dynamically generated css code goes here:
do_action('mizox_dynamic_css_generator_action');