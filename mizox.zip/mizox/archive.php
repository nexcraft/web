<?php
/**
 * The template for displaying archive pages
 */

get_header();

mizox_get_title_area_parts();

mizox_get_blog();

get_footer();
