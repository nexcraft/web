<div class="post-thumb">
<?php mizox_get_blocks_template_part( 'thumb', null, 'blog-single/tpl/parts', $params ); ?>
</div>