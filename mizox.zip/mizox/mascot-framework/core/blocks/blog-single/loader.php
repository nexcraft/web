<?php
if ( mascot_core_plugin_installed() && mascot_core_mizox_plugin_installed() ) {
	require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/blog-single/blog-single-metabox.php';
}
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/blog-single/blog-single-css-generators.php';
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/blog-single/blog-single-functions.php';