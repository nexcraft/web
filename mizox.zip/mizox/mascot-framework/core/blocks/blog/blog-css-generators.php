<?php

if (!function_exists('mizox_sidebar_widget_title_line_bottom_color')) {
	/**
	 * Generate CSS codes for Sidebar Widget Title Custom Line Bottom Color
	 */
	function mizox_sidebar_widget_title_line_bottom_color() {
		global $mizox_redux_theme_opt;
		$var_name = 'sidebar-settings-sidebar-title-line-bottom-custom-color';
		//If Make Line Bottom Theme Colored?
		if( $mizox_redux_theme_opt['sidebar-settings-sidebar-title-line-bottom-theme-colored'] != '' ) {
			return;
		}

		$declaration = array();
		$selector = array(
			'.widget .widget-title.widget-title-line-bottom:after'
		);

		$declaration['background-color'] = $mizox_redux_theme_opt[$var_name];
		mizox_dynamic_css_generator($selector, $declaration);
	}
	add_action('mizox_dynamic_css_generator_action', 'mizox_sidebar_widget_title_line_bottom_color');
}