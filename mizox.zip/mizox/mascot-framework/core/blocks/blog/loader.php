<?php
if ( mascot_core_mizox_plugin_installed() ) {
	require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/blog/blog-metabox.php';
}
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/blog/blog-css-generators.php';
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/blog/blog-functions.php';