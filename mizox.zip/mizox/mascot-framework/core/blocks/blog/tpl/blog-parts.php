<?php
	/**
	* mizox_before_blog_section hook.
	*
	*/
	do_action( 'mizox_before_blog_section' );
?>
<section>
	<div class="<?php echo esc_attr( $container_type ); ?>">
		<?php
			/**
			* mizox_blog_container_start hook.
			*
			*/
			do_action( 'mizox_blog_container_start' );
		?>

		<div class="blog-posts">
			<?php
				mizox_get_blog_sidebar_layout();
			?>
		</div>

	<?php
		/**
		* mizox_blog_container_end hook.
		*
		*/
		do_action( 'mizox_blog_container_end' );
	?>
	</div>
</section>
<?php
	/**
	* mizox_after_blog_section hook.
	*
	*/
	do_action( 'mizox_after_blog_section' );
?>
