<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	if (is_sticky()) {
		echo '<div class="post-sticky-icon" title="' . esc_attr__('Sticky Post', 'mizox') . '"><i class="fas fa-map-pin"></i></div>';
	}
	?>
	<?php if( $show_post_featured_image ) { ?>
	<div class="entry-header">
		<?php do_action( 'mizox_blog_post_entry_header_start' ); ?>
		<?php mizox_get_post_thumbnail( $post_format ); ?>
		<?php if ( has_post_thumbnail() ) { ?>
			<?php if( mizox_get_redux_option( 'blog-settings-post-meta', true, 'show-post-date' ) ) { ?>
				<div class="post-single-meta">
					<?php mizox_post_shortcode_single_meta( 'show-post-date-split' ); ?>
				</div>
			<?php } ?>
		<?php } ?>
		<?php do_action( 'mizox_blog_post_entry_header_end' ); ?>
	</div>
	<?php } ?>
	<div class="entry-content">
		<?php do_action( 'mizox_blog_post_entry_content_start' ); ?>
		<div class="content">

			<div class="post-info">
				<div class="author-thumb">
					<?php if($avatar = get_avatar(get_the_author_meta('ID')) !== FALSE): ?>
						<?php echo get_avatar( get_the_author_meta( 'ID' ), 128 ); ?>
					<?php else: ?>
						<img src="https://via.placeholder.com/150x150" alt="avatar">
					<?php endif; ?>
				</div>
				<?php mizox_post_meta(); ?>
			</div>

			<?php mizox_get_post_title(); ?>
			<div class="post-excerpt">
				<?php mizox_get_excerpt(); ?>
			</div>
		</div>

		<div class="bottom-box">
			<div class="comments"><i class="fa fa-comments-o"></i> <?php mizox_get_comments_number(); ?></div>
			<a href="<?php the_permalink();?>" class="read-more">More</a>
    </div>
		<?php do_action( 'mizox_blog_post_entry_content_end' ); ?>
	</div>
	<div class="clearfix"></div>
</article>