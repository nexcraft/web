<div class="search-box">
	<h5 class="heading"><?php echo esc_html( $search_box_heading ); ?></h5>
	<div class="paragraph"><?php echo esc_html( $search_box_paragraph ); ?></div>
	<?php get_search_form(); ?>
</div>