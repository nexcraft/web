<?php

if (!function_exists('mizox_layout_settings_boxed_layout_padding_top_bottom')) {
	/**
	 * Generate CSS codes for Boxed Layout - Padding Top & Bottom
	 */
	function mizox_layout_settings_boxed_layout_padding_top_bottom() {
		global $mizox_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-padding-top-bottom';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $mizox_redux_theme_opt ) ) {
			return;
		}

		//if Page Layout boxed
		if( mizox_get_redux_option( 'layout-settings-page-layout' ) == 'boxed' ) {
			$padding_top = $mizox_redux_theme_opt[$var_name]['padding-top'];
			$padding_bottom = $mizox_redux_theme_opt[$var_name]['padding-bottom'];

			if( !empty( $padding_top ) && $padding_top != "" ) {
				$padding_top = mizox_remove_suffix( $padding_top, 'px');
				$declaration['padding-top'] = $padding_top . 'px';
			}
			if( !empty( $padding_bottom ) && $padding_bottom != "" ) {
				$padding_bottom = mizox_remove_suffix( $padding_bottom, 'px');
				$declaration['padding-bottom'] = $padding_bottom . 'px';
			}
		}

		mizox_dynamic_css_generator($selector, $declaration);
	}
	add_action('mizox_dynamic_css_generator_action', 'mizox_layout_settings_boxed_layout_padding_top_bottom');
}


if (!function_exists('mizox_stretched_layout_background_color')) {
	/**
	 * Generate CSS codes for Stretched Layout - Background Color
	 */
	function mizox_stretched_layout_background_color() {
		global $mizox_redux_theme_opt;
		$var_name = 'layout-settings-stretched-layout-bg-bgcolor';
		$declaration = array();
		$selector = array(
			'body.tm-stretched-layout',
		);

		//if empty then return
		if( mizox_get_redux_option( 'layout-settings-page-layout' ) != 'stretched' ) {
			return;
		}
		if( !array_key_exists( $var_name, $mizox_redux_theme_opt ) ) {
			return;
		}

		if( mizox_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-color' ) {
			if( $mizox_redux_theme_opt[$var_name] != "" ) {
				$declaration['background-color'] = $mizox_redux_theme_opt[$var_name];
			}
			mizox_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('mizox_dynamic_css_generator_action', 'mizox_stretched_layout_background_color');
}


if (!function_exists('mizox_boxed_layout_background_color')) {
	/**
	 * Generate CSS codes for Boxed Layout - Background Color
	 */
	function mizox_boxed_layout_background_color() {
		global $mizox_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-bg-type-bgcolor';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $mizox_redux_theme_opt ) ) {
			return;
		}

		if( mizox_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-color' ) {
			if( $mizox_redux_theme_opt[$var_name] != "" ) {
				$declaration['background-color'] = $mizox_redux_theme_opt[$var_name];
			}
			mizox_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('mizox_dynamic_css_generator_action', 'mizox_boxed_layout_background_color');
}




if (!function_exists('mizox_boxed_layout_background_pattern')) {
	/**
	 * Generate CSS codes for Boxed Layout - Background Pattern
	 */
	function mizox_boxed_layout_background_pattern() {
		global $mizox_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-bg-type-pattern';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $mizox_redux_theme_opt ) ) {
			return;
		}

		if( mizox_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-patter' ) {
			if( $mizox_redux_theme_opt[$var_name] != "" ) {
				$declaration['background-image'] = 'url('.$mizox_redux_theme_opt[$var_name].')';
			}
			mizox_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('mizox_dynamic_css_generator_action', 'mizox_boxed_layout_background_pattern');
}


if (!function_exists('mizox_boxed_layout_bg')) {
	/**
	 * Generate CSS codes for Widget Footer Background
	 */
	function mizox_boxed_layout_bg() {
		global $mizox_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-bg-type-bgimg';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $mizox_redux_theme_opt ) ) {
			return;
		}

		if( mizox_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-image' ) {
			$declaration = mizox_redux_option_field_background( $var_name );
			mizox_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('mizox_dynamic_css_generator_action', 'mizox_boxed_layout_bg');
}

