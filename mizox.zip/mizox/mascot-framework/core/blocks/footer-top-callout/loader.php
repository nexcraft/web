<?php
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/footer-top-callout/footer-top-callout-css-generators.php';
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/footer-top-callout/footer-top-callout-functions.php';