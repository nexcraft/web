<?php

require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/maintenance-mode/maintenance-mode-css-generators.php';
