<?php
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/footer/footer-css-generators.php';
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/footer/footer-functions.php';