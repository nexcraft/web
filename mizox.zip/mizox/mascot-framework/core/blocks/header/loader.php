<?php
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/header/header-css-generators.php';
require_once MIZOX_FRAMEWORK_DIR . '/core/blocks/header/header-functions.php';