
	<?php
	/**
	* mizox_before_top_sliders_container hook.
	*
	*/
	do_action( 'mizox_before_top_sliders_container' );
	?>
	<div class="top-sliders-container">
		<?php
			/**
			* mizox_top_sliders_container_start hook.
			*
			*/
			do_action( 'mizox_top_sliders_container_start' );
		?>

		<?php
			echo mizox_get_top_main_slider();
		?>
		
		<?php
			/**
			* mizox_top_sliders_container_end hook.
			*
			*/
			do_action( 'mizox_top_sliders_container_end' );
		?>
	</div>
	<?php
	/**
	* mizox_after_top_sliders_container hook.
	*
	*/
	do_action( 'mizox_after_top_sliders_container' );
	?>
