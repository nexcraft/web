<?php
/**
 * The template for displaying 404 pages (not found)
 *
 */
$header_return_true_false = ( mizox_get_redux_option( '404-page-settings-show-header', true ) == true ) ? 'mizox_return_true' : 'mizox_return_false';
add_filter( 'mizox_filter_show_header', $header_return_true_false );

$footer_return_true_false = ( mizox_get_redux_option( '404-page-settings-show-footer', true ) == true ) ? 'mizox_return_true' : 'mizox_return_false';
add_filter( 'mizox_filter_show_footer', $footer_return_true_false );

get_header();

mizox_get_title_area_parts();

mizox_get_404_parts();

get_footer();
