<?php
/**
 * The template for displaying archive for portfolio
 */

get_header();

mizox_get_title_area_parts();

mizox_get_staffs();

get_footer();
