<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the .main-content div and #wrapper
 *
 */
?>


	<?php mizox_get_footer_top_callout(); ?>


	<?php
		/**
		 * mizox_main_content_end hook.
		 *
		 */
		do_action( 'mizox_main_content_end' );
	?>
	</div>
	<!-- main-content end --> 
	<?php
		/**
		 * mizox_after_main_content hook.
		 *
		 */
		do_action( 'mizox_after_main_content' );
	?>


	<?php if( apply_filters('mizox_filter_show_footer', true) ): ?>
	<?php mizox_get_footer_parts(); ?>
	<?php endif; ?>
	
	<?php
		/**
		 * mizox_wrapper_end hook.
		 *
		 */
		do_action( 'mizox_wrapper_end' );
	?>
</div>
<!-- wrapper end -->
<?php
	/**
	 * mizox_body_tag_end hook.
	 *
	 */
	do_action( 'mizox_body_tag_end' );
?>
<?php if( class_exists('Woocommerce') && mascot_core_mizox_plugin_installed() ) { mizox_floating_cart_sidebar(); } ?>
<?php
	/**
	 * nav_search_icon_popup_html hook.
	 *
	 */
	global $nav_search_holder_id;
	do_action( 'mizox_nav_search_icon_popup_html', $nav_search_holder_id );
?>
<?php wp_footer(); ?>
</body>
</html>
